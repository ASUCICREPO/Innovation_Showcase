import { NavBar, Component1, StandardCard, StandardCardCollection, TableHeading, TableContent, TableHeading2,TableHeading2Body,
  TableHeading2BodyCollection, 
  HeroLayout3} from './ui-components'
import {
  HeroLayout1 
} from './ui-components';


import ReactDOM from "react-dom";

import { BrowserRouter, Routes, Route } from "react-router-dom";
import HomePage from "./pages/Home";
import Project from "./pages/Projects";
import Demo from "./pages/Demos";
import Layout from "./pages/Layout";
import Gunshot from "./pages/gunshot_city";


export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Layout />}>
          <Route index element={<HomePage />} />
          <Route path="home" element={<HomePage />} />
          <Route path="projects" element={<Project />} />
          <Route path="demos" element={<Demo />} />
          <Route path="gunshot" element={<Gunshot />} />

        </Route>
      </Routes>
    </BrowserRouter>
  );
}

ReactDOM.render(<App />, document.getElementById("root"));
