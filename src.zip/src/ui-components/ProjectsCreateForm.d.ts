/***************************************************************************
 * The contents of this file were generated with Amplify Studio.           *
 * Please refrain from making any modifications to this file.              *
 * Any changes to this file will be overwritten when running amplify pull. *
 **************************************************************************/

import * as React from "react";
import { GridProps, TextFieldProps } from "@aws-amplify/ui-react";
import { EscapeHatchProps } from "@aws-amplify/ui-react/internal";
export declare type ValidationResponse = {
    hasError: boolean;
    errorMessage?: string;
};
export declare type ValidationFunction<T> = (value: T, validationResponse: ValidationResponse) => ValidationResponse | Promise<ValidationResponse>;
export declare type ProjectsCreateFormInputValues = {
    projectCategory?: string;
    customer?: string;
    cicTeam?: string;
    projectName?: string;
    projectType?: string;
    awsService?: string;
    img_Url?: string;
    demo_Url?: string;
    description?: string;
};
export declare type ProjectsCreateFormValidationValues = {
    projectCategory?: ValidationFunction<string>;
    customer?: ValidationFunction<string>;
    cicTeam?: ValidationFunction<string>;
    projectName?: ValidationFunction<string>;
    projectType?: ValidationFunction<string>;
    awsService?: ValidationFunction<string>;
    img_Url?: ValidationFunction<string>;
    demo_Url?: ValidationFunction<string>;
    description?: ValidationFunction<string>;
};
export declare type PrimitiveOverrideProps<T> = Partial<T> & React.DOMAttributes<HTMLDivElement>;
export declare type ProjectsCreateFormOverridesProps = {
    ProjectsCreateFormGrid?: PrimitiveOverrideProps<GridProps>;
    projectCategory?: PrimitiveOverrideProps<TextFieldProps>;
    customer?: PrimitiveOverrideProps<TextFieldProps>;
    cicTeam?: PrimitiveOverrideProps<TextFieldProps>;
    projectName?: PrimitiveOverrideProps<TextFieldProps>;
    projectType?: PrimitiveOverrideProps<TextFieldProps>;
    awsService?: PrimitiveOverrideProps<TextFieldProps>;
    img_Url?: PrimitiveOverrideProps<TextFieldProps>;
    demo_Url?: PrimitiveOverrideProps<TextFieldProps>;
    description?: PrimitiveOverrideProps<TextFieldProps>;
} & EscapeHatchProps;
export declare type ProjectsCreateFormProps = React.PropsWithChildren<{
    overrides?: ProjectsCreateFormOverridesProps | undefined | null;
} & {
    clearOnSuccess?: boolean;
    onSubmit?: (fields: ProjectsCreateFormInputValues) => ProjectsCreateFormInputValues;
    onSuccess?: (fields: ProjectsCreateFormInputValues) => void;
    onError?: (fields: ProjectsCreateFormInputValues, errorMessage: string) => void;
    onChange?: (fields: ProjectsCreateFormInputValues) => ProjectsCreateFormInputValues;
    onValidate?: ProjectsCreateFormValidationValues;
} & React.CSSProperties>;
export default function ProjectsCreateForm(props: ProjectsCreateFormProps): React.ReactElement;
