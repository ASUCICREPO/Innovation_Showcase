import { NavBar, Component1, StandardCard, StandardCardCollection, TableHeading, TableContent, TableHeading2,TableHeading2Body,
    TableHeading2BodyCollection,DemoComponent, 
    HeroLayout3} from '../ui-components'
  import {
    HeroLayout1 
  } from '../ui-components';
  
  const Demo = () => {
    return (
      <div classname="App">
  
        <NavBar width='100%' />
        <header className='App-header'>
        <div className='container'>
          {/* <Component1/> */} 
  
  
          
  
        </div>
       
        </header>
        <DemoComponent width = '100%'/>

  
  
  
  
      </div>
    )
  }
  
  export default Demo;
  