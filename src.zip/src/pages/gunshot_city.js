import { NavBar, Component1, StandardCard, StandardCardCollection, TableHeading, TableContent, TableHeading2,TableHeading2Body,
    TableHeading2BodyCollection,ProjectCollection, 
    HeroLayout3,
    ProjectComponent,
    } from '../ui-components'
  import {
    HeroLayout1 
  } from '../ui-components';
  
  const Gunshot = () => {
    return (
      <div classname="App">
  
        <NavBar width='100%' />
        <header className='App-header'>
        <div className='container'>          
  
        </div>
        <div className='table'>
   
         </div> 
        </header>
        
        <ProjectComponent />

  
  
  
      </div>
    )
  }
  
  export default Gunshot;
  