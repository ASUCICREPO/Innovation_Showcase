import { NavBar, Component1, StandardCard, StandardCardCollection, TableHeading, TableContent, TableHeading2,TableHeading2Body,
  TableHeading2BodyCollection, 
  HeroLayout3} from '../ui-components'
import {
  HeroLayout1 
} from '../ui-components';


const HomePage = () => {
  return (
    <div classname="App">

      <NavBar width='100%' />
      <HeroLayout3 width='100%' marginBottom={'20px'}/>
      <header className='App-header'>
      <div className='container'>
        <StandardCardCollection />
        {/* <Component1/> */} 


        

      </div>
      <div className='table'>
        <TableHeading2 marginTop={"30px"} marginBottom="10px"/>
        
        
        <TableHeading2BodyCollection width = '100%' marginBottom = "30px"/>
       </div> 
      </header>
      




    </div>
    
  )
}

export default HomePage;
